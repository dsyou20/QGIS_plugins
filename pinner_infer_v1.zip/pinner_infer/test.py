import requests

meta_data = {
    'file': ("C:/Users/avcdd/Desktop/fd/base_zl_20_tx_289887.20295001235_ty_303711.1352999966__from_5S_099_174.tif"),
    #'geojson': (self.output_geojson_path, geojson_data, 'application/json')
    #'meta': ('meta', json.dumps({'model': 'yolo'}), 'application/json')
    }
print("1111111")
headers = {
    'Content-type': 'multipart/form-data'
}
print("2222222")

response = requests.post("http://192.168.100.178:7778/inference", files=meta_data, headers=headers)
print("3333333")

print(response.text)

#응답 상태 코드 확인
if response.status_code == 200:
    print('요청 성공')
else:
    print(f'요청 실패: {response.status_code}')
